INS-HDGS-CMT, Brain Informatics revised submission, source package dated 2026-09-18
Title: Dynamic Functional Graph Learning for Subject-Independent Consumer Engagement Decoding from EEG and Eye Tracking: A Leakage-Aware NeuMa Study

Main file : INS_HDGS_CMT_manuscript.tex  (compile with pdfLaTeX, run twice; bibliography is inline)
Supplement: INS_HDGS_CMT_supplementary.tex (compile with pdfLaTeX, run twice)
Class     : sn-jnl.cls (Springer Nature, sn-basic numbered style)
Figures   : figures/ (all referenced by both files; the .bib mirrors the inline bibliography and is not needed to build)
